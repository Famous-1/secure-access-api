<?php echo e($slot); ?>

<?php /**PATH /home/victor/workspace/personal/estate-mgt/secure-access-api/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>